const formulario = document.querySelector("#formulario");




//mis funciones
function validarFormulario(evento){
    e.preventDefault();
    const rut = document.querySelector("#rut").value
    const nombre = document.querySelector("#nombre").value
    const apellido_paterno = document.querySelector("#apellido_paterno").value
    const apellido_materno = document.querySelector("#apellido_materno").value
    const ecorreo = document.querySelector("#correo").value
    const fecha = document.querySelector("#fecha_nacimiento").value
    const numero = document.querySelector("#numero").value
    const direccion = document.querySelector("#direccion").value





}